from flask import Flask, request, jsonify, render_template
import numpy as np
import joblib

app = Flask(__name__)

# Load the trained KNN model
knn_model = joblib.load('KNeighborsClassifier.joblib')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        pulse_rate = float(request.form['pulse_rate'])
        skin_conductance = float(request.form['gsr'])
        oxygen_saturation = float(request.form['oxygen_saturation'])

        # Prepare the feature vector for prediction
        features = np.array([[pulse_rate, oxygen_saturation, skin_conductance]])

        # Predict the emotion
        prediction = knn_model.predict(features)
        emotion = prediction[0]

        return jsonify({'emotion': emotion})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': str(e)})
    
@app.route('/recommendations')
def recommendations():
    return render_template('recommendations.html')

if __name__ == '__main__':
    app.run(debug=True)
